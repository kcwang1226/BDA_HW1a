wget 'https://docs.google.com/uc?export=download&id=1opGAhEesWSMf9aKD-BrylxeTrgSbtNZK' -O video.zip
unzip video.zip
rm video.zip